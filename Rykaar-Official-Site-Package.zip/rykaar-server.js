'use strict';

// Local Gemini proxy for the Rykaar static site. The API key is never served to the browser.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 4178);
const HOST = process.env.HOST || '127.0.0.1';
const PAGE = path.join(__dirname, 'Rykaar-Official-site.html');
const PASSCODE_FILE = path.join(__dirname, '.rykaar-admin-passcode.json');
const isLoopback = HOST === '127.0.0.1' || HOST === 'localhost' || HOST === '::1';
let adminPasscode = process.env.RYKAAR_ADMIN_PASSCODE || (isLoopback ? 'admin' : '');
let adminPasscodeHash = null;
if (!process.env.RYKAAR_ADMIN_PASSCODE && isLoopback) {
  try { adminPasscodeHash = JSON.parse(fs.readFileSync(PASSCODE_FILE, 'utf8')); adminPasscode = ''; }
  catch { /* First local run uses the site's default admin passcode. */ }
}
let apiKeyOverride = null;
let keyDisabled = false;
let settings = {
  model: 'gemini-3.8-flash',
  title: 'Chat with Rykaar',
  greeting: 'Welcome to Rykaar. How can we help you today?',
  instructions: "You are Rykaar Official's helpful virtual assistant. Help visitors with Rykaar Real Estate, Rykaar Jewellers, Rykaar One business consultancy, and Rykaar Resorts. Do not invent prices, availability, or company policies. For verified details, direct visitors to 8618884588 or rykaarofficial@gmail.com."
};
const rateLimits = new Map();

function getApiKey() {
  if (keyDisabled) return '';
  return apiKeyOverride || process.env.GEMINI_API_KEY || '';
}

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify(data));
}

function readJson(req, limit = 30000) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (Buffer.byteLength(body) > limit) {
        reject(Object.assign(new Error('Request is too large.'), { status: 413 }));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(Object.assign(new Error('Invalid request.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return false;
  try { return new URL(origin).host === req.headers.host; }
  catch { return false; }
}

function publicStatus() {
  return { connected: Boolean(getApiKey()), model: settings.model, title: settings.title, greeting: settings.greeting, instructions: settings.instructions };
}

function authorized(req, body) {
  if (!isLoopback && !process.env.RYKAAR_ADMIN_PASSCODE) return false;
  if (adminPasscodeHash && body.adminPasscode) {
    try {
      const salt = Buffer.from(adminPasscodeHash.salt, 'hex');
      const expected = Buffer.from(adminPasscodeHash.hash, 'hex');
      const actual = crypto.scryptSync(String(body.adminPasscode), salt, expected.length);
      return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
    } catch { return false; }
  }
  return Boolean(adminPasscode) && body.adminPasscode === adminPasscode;
}

function checkRateLimit(req) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const recent = (rateLimits.get(ip) || []).filter(t => now - t < 60000);
  if (recent.length >= 20) return false;
  recent.push(now); rateLimits.set(ip, recent); return true;
}

async function handleChat(req, res) {
  if (!sameOrigin(req)) return sendJson(res, 403, { error: 'Chat request origin was not accepted.' });
  if (!checkRateLimit(req)) return sendJson(res, 429, { error: 'Please wait a moment before sending another message.' });
  const apiKey = getApiKey();
  if (!apiKey) return sendJson(res, 503, { error: 'Rykaar Gemini chat is not connected yet. The site administrator can connect it in Admin CMS → Gemini Chat.' });
  let body;
  try { body = await readJson(req, 30000); }
  catch (e) { return sendJson(res, e.status || 400, { error: e.message }); }
  const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  const contents = messages.map(m => ({ role: m.role === 'model' ? 'model' : 'user', parts: [{ text: String(m.text || '').slice(0, 2000) }] })).filter(m => m.parts[0].text.trim());
  if (!contents.length) return sendJson(res, 400, { error: 'Type a message to start chatting.' });
  try {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(settings.model)}:generateContent`;
    const apiResponse = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: settings.instructions }] },
        contents,
        generationConfig: { maxOutputTokens: 700, temperature: 0.6 }
      }),
      signal: AbortSignal.timeout(45000)
    });
    const result = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const message = result.error && result.error.message ? result.error.message : `Gemini returned HTTP ${apiResponse.status}.`;
      return sendJson(res, 502, { error: message.slice(0, 500) });
    }
    const reply = (result.candidates || []).flatMap(c => c.content && c.content.parts || []).map(p => p.text || '').join('').trim();
    if (!reply) return sendJson(res, 502, { error: 'Gemini did not return a text reply. Please try again.' });
    sendJson(res, 200, { reply });
  } catch (e) {
    sendJson(res, 502, { error: e.name === 'TimeoutError' ? 'Gemini took too long to respond. Please try again.' : 'Could not reach Gemini. Check the server connection and try again.' });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
  if (req.method === 'GET' && url.pathname === '/api/gemini/status') return sendJson(res, 200, publicStatus());
  if (req.method === 'POST' && url.pathname === '/api/gemini/admin-passcode') {
    if (!sameOrigin(req)) return sendJson(res, 403, { error: 'Settings request origin was not accepted.' });
    let body;
    try { body = await readJson(req, 4000); }
    catch (e) { return sendJson(res, e.status || 400, { error: e.message }); }
    if (!authorized(req, body)) return sendJson(res, 403, { error: 'Current admin passcode did not match.' });
    if (process.env.RYKAAR_ADMIN_PASSCODE) return sendJson(res, 403, { error: 'The server admin passcode is managed by its environment settings.' });
    const newPasscode = String(body.newPasscode || '');
    if (newPasscode.length < 3 || newPasscode.length > 200) return sendJson(res, 400, { error: 'Passcode must be between 3 and 200 characters.' });
    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(newPasscode, salt, 64);
    adminPasscodeHash = { salt: salt.toString('hex'), hash: hash.toString('hex') };
    adminPasscode = '';
    fs.writeFileSync(PASSCODE_FILE, JSON.stringify(adminPasscodeHash), { mode: 0o600 });
    return sendJson(res, 200, { saved: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/gemini/settings') {
    if (!sameOrigin(req)) return sendJson(res, 403, { error: 'Settings request origin was not accepted.' });
    let body;
    try { body = await readJson(req, 12000); }
    catch (e) { return sendJson(res, e.status || 400, { error: e.message }); }
    if (!authorized(req, body)) return sendJson(res, 403, { error: 'Admin verification failed. Check the Admin CMS passcode configuration.' });
    if (body.clearKey) { apiKeyOverride = ''; keyDisabled = true; }
    else if (typeof body.key === 'string' && body.key.trim()) {
      const key = body.key.trim();
      if (key.length < 12 || key.length > 500) return sendJson(res, 400, { error: 'That API key does not look valid. Check it and try again.' });
      apiKeyOverride = key; keyDisabled = false;
    }
    if (typeof body.model === 'string' && /^[A-Za-z0-9._-]{1,100}$/.test(body.model.trim())) settings.model = body.model.trim();
    if (typeof body.title === 'string') settings.title = body.title.trim().slice(0, 100) || settings.title;
    if (typeof body.greeting === 'string') settings.greeting = body.greeting.trim().slice(0, 500) || settings.greeting;
    if (typeof body.instructions === 'string') settings.instructions = body.instructions.trim().slice(0, 4000) || settings.instructions;
    return sendJson(res, 200, publicStatus());
  }
  if (req.method === 'POST' && url.pathname === '/api/gemini/chat') return handleChat(req, res);
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/Rykaar-Official-site.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    return fs.createReadStream(PAGE).on('error', () => { if (!res.headersSent) res.writeHead(500); res.end('Rykaar site page is unavailable.'); }).pipe(res);
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
  res.end('Not found');
});

server.listen(PORT, HOST, () => console.log(`Rykaar site available at http://${HOST}:${PORT}/Rykaar-Official-site.html`));
